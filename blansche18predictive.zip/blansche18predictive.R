#######################################################################################################
# DIVERS
#######################################################################################################

emptyparams <-
  function ()
  {
    res = list ()
    class (res) = "params"
    return (res)
  }

stdev = function (v)
{
  m = mean (v)
  res = sqrt (mean ((v - m)^2))
  return (res)
}

#######################################################################################################
# FONCTIONS D'EXTRACTION DES FEATURES
#######################################################################################################

extract.moneyseries = function (learning.time, learning.goal, learning.money, learning.backers, states, state, featurestep = 1, ...)
{
  features = rep (as.numeric (colnames (learning.money) [state]), nrow (learning.money))
  features = cbind (features, learning.money [, seq (featurestep, state, featurestep)])
  rownames (features) = NULL
  colnames (features) = c ("Progress", colnames (learning.money) [seq (featurestep, state, featurestep)])
  return (features)
}

extract.scaledmoneyseries = function (learning.time, learning.goal, learning.money, learning.backers, states, state, featurestep = 1, ...)
{
  features = rep (as.numeric (colnames (learning.money) [state]), nrow (learning.money))
  features = cbind (features, learning.money [, seq (featurestep, state, featurestep)])
  if (ncol (features) > 2)
  {
    m = apply (features [-1, -1], 2, mean)
    stdev = apply (features [-1, -1], 2, FUN = function (v) sqrt (mean ((v - mean (v))^2)))
    stdev [stdev == 0] = 1
    features [, -1] = sweep (features [, -1], 2, m, "-")
    features [, -1] = sweep (features [, -1], 2, stdev, "/")
  }
  rownames (features) = NULL
  colnames (features) = c ("Progress", colnames (learning.money) [seq (featurestep, state, featurestep)])
  return (features)
}

xlastmoney = function (learning.money, state) learning.money [, state]

extract.lastmoney = function (learning.time, learning.goal, learning.money, learning.backers, states, state, ...)
{
  features = rep (as.numeric (colnames (learning.money) [state]), nrow (learning.money))
  features = cbind (features, learning.money [, state])
  rownames (features) = NULL
  colnames (features) = c ("Progress", "Last money")
  return (features)
}

extract.moneydiff = function (learning.time, learning.goal, learning.money, learning.backers, states, state, featurestep = 1, ...)
{
  features = rep (as.numeric (colnames (learning.money) [state]), nrow (learning.money))
  progress = as.numeric (colnames (learning.money) [1:state])
  all = seq (featurestep, ncol (learning.money [, 1:state]), featurestep)
  if (length (all) > 1)
  {
    prev = all [-length (all)]
    current = all [-1]
    delta = progress [current] - progress [prev]
    diff = learning.money [, current] - learning.money [, prev]
    if (is.vector (diff))
      diff = diff / delta
    else
      diff = sweep (diff, 2, delta, "/")
    features = cbind (features, diff)
    rownames (features) = NULL
    colnames (features) = c ("Progress", progress [current])
  }
  else
  {
    features = cbind (features, rep (0, nrow (learning.money)))
    rownames (features) = NULL
    colnames (features) = c ("Progress", progress [state])
  }
  return (features)
}

extract.moneypva = function (learning.time, learning.goal, learning.money, learning.backers, states, state, featurestep = 1, ...)
{
  all = seq (featurestep, state, featurestep)
  n = length (all)
  position = learning.money [, state]
  velocity = NULL
  acceleration = NULL
  if (n > 1)
    velocity = position - learning.money [, state - featurestep]
  else
    velocity = rep (0, nrow (learning.money))
  if (n > 2)
  {
    prevv = learning.money [, state - featurestep] - learning.money [, state - 2 * featurestep]
    acceleration = velocity - prevv
  }
  else
    acceleration = rep (0, nrow (learning.money))
  features = rep (as.numeric (colnames (learning.money) [state]), nrow (learning.money))
  features = cbind (features, position, velocity, acceleration)
  m = apply (features [-1, -1], 2, mean)
  stdev = apply (features [-1, -1], 2, FUN = function (v) sqrt (mean ((v - mean (v))^2)))
  stdev [stdev == 0] = 1
  features [, -1] = sweep (features [, -1], 2, m, "-")
  features [, -1] = sweep (features [, -1], 2, stdev, "/")
  colnames (features) = c ("Progress", "Position", "Velocity", "Acceleration")
  return (features)
}

extract.auc = function (learning.money, state) apply (learning.money [, 1:state], 1, sum)
extract.selection = function (learning.time, learning.goal, learning.money, learning.backers, states, state, scale = T, select = NULL, ...)
{
  s = select
  if (is.null (select))
    s = rep (T, 8)
  features = rep (as.numeric (colnames (learning.money) [state]), nrow (learning.money))
  if (s [1])
    features = cbind (features, learning.money [, state])
  if (s [2])
  {
    if (state > 10)
      features = cbind (features, learning.money [, state] - learning.money [, state - 10])
    else
      features = cbind (features, learning.money [, state])
  }
  if (s [3])
    features = cbind (features, extract.auc (learning.money, state))
  if (s [4])
    features = cbind (features, learning.money [, 10])
  if (s [5])
    features = cbind (features, learning.backers [, state])
  if (s [6])
    features = cbind (features, learning.time [, 2] - learning.time [, 1])
  if (s [7])
    features = cbind (features, learning.goal [, 1])
  if (s [8])
  {
    div = ifelse (learning.backers [, state] == 0, 1, learning.backers [, state])
    features = cbind (features, learning.money [, state] / div)
  }
  if (scale && (ncol (features) > 2))
  {
    m = apply (features [-1, -1], 2, mean)
    stdev = apply (features [-1, -1], 2, FUN = function (v) sqrt (mean ((v - mean (v))^2)))
    stdev [stdev == 0] = 1
    features [, -1] = sweep (features [, -1], 2, m, "-")
    features [, -1] = sweep (features [, -1], 2, stdev, "/")
  }
  rownames (features) = NULL
  colnames (features) = c ("Progress", "Last money", "Local slope", "AUC", "Impulse", "Backers", "Duration", "Goal", "Average pledge") [c (T, s)]
  return (features)
}

#######################################################################################################
# RECHERCHE EXHAUSTIVE POUR LA SÉLECTION DE VARIABLES
#######################################################################################################

nextSelect = function (select)
{
  res = select
  pos = 1
  res [pos] = !res [pos]
  while (!res [pos])
  {
    pos = pos + 1
    res [pos] = !res [pos]
  }
  return (res)
}

selecttofile = function (select)
{
  core = paste (ifelse (select, 1, 0), collapse = "")
  res = paste ("pred", core, sep = ".")
  return (res)
}

multitest = function (time, goal, money, backers)
{
  select = rep (F, 8)
  end = F
  while (!end)
  {
    select = nextSelect (select)
    filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/", selecttofile (select), ".data", sep = "")
    if (!file.exists (filename))
    {
      print (selecttofile (select))
      pred = crossvalidation (KNNR, extract.selection, time, goal, money, backers, step = 10, pred = coeffmedian, k = 16, select = select) [[1]]
      save.predictions (pred, selecttofile (select))
    }
    end = all (select)
  }
}

#######################################################################################################
# FONCTIONS DE REGRESSION À PARTIR DES VOISINS
#######################################################################################################

average = function (x, y, newx)
{
  return (mean (y))
}

amedian = function (x, y, newx)
{
  return (median (y))
}

shift = function (x, y, newx)
{
  n = length (newx)
  shift = unlist (newx [n] - mean (x))
  return (shift + mean (y))
}

coeff = function (x, y, newx)
{
  n = length (newx)
  m = mean (x)
  coeff = 1
  if (m > 0)
    coeff = newx [n] / m
  return (coeff * mean (y))
}

shiftcoeff = function (x, y, newx)
{
  n = length (newx)
  m = mean (x)
  shift = unlist (newx [n] - m) / 2
  shifted = newx [n] - shift
  coeff = 1
  if (m > 0)
    coeff = shifted / m
  return (shift + coeff * mean (y))
}

shiftmedian = function (x, y, newx)
{
  n = length (newx)
  shift = unlist (newx [n] - median (x))
  return (shift + median (y))
}

coeffmedian = function (x, y, newx)
{
  n = length (newx)
  m = median (x)
  coeff = 1
  if (m > 0)
    coeff = newx [n] / m
  return (coeff * median (y))
}

shiftcoeffmedian = function (x, y, newx)
{
  n = length (newx)
  m = median (x)
  shift = unlist (newx [n] - m) / 2
  shifted = newx [n] - shift
  coeff = 1
  if (m > 0)
    coeff = shifted / m
  return (shift + coeff * median (y))
}

#######################################################################################################
# FONCTIONS DE  POUR K-NN (DISSIMILARITÉ, ETC.)
#######################################################################################################

library (flexclust)
deuclid = function (train, test)
{
  return (dist2 (train, test))
}

library (flexclust)
library (dtwclust)
ddtw = function (train, test)
{
  return (dist (test, train, method = "dtw_basic"))
}

library (StatMatch)
dmahalanobis = function (train, test)
{
  return (mahalanobis.dist (test, train, var (train)))
}

#######################################################################################################
# KNNR (RÉGRESSION AVEC K-NN)
#######################################################################################################

setClass ("knnr", representation (train = "data.frame", target = "vector", lastmoney = "vector", k = "numeric"))

KNNR <-
  function (train, target, lastmoney, k = 3, ...)
  {
    res = list (train = train, target = target, lastmoney = lastmoney, k = k)
    class (res) = "knnr"
    return (res)
  }

predict.knnr <-
  function (object, test, pred = average, distance = deuclid, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      train = object$train [, -1]
      ttest = test [-1]
      if (is.vector (train))
        train = data.frame (matrix (train, ncol = 1))
      distances = distance (train, ttest)
      ranks = rank (unlist (distances), ties.method = "min")
      neighbors = which (ranks <= object$k)
      neighborsx = (object$lastmoney [-1]) [neighbors]
      neighborsy = object$target [neighbors]
      res = pred (neighborsx, neighborsy, object$lastmoney [1])
    }
    return (res)
  }
setMethod ("predict", "knnr", function (object, ...) predict.knnr (object, ...))

#######################################################################################################
# MAXNN (K-NN AVEC TOUS LES VOISINS)
#######################################################################################################

setClass ("maxnn", representation (train = "data.frame", target = "vector", lastmoney = "vector", k = "numeric"))

MAXNN <-
  function (train, target, lastmoney, ...)
  {
    res = list (train = train, target = target, lastmoney = lastmoney)
    class (res) = "maxnn"
    return (res)
  }

predict.maxnn <-
  function (object, test, pred = average, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      neighborsx = object$lastmoney [-1]
      neighborsy = object$target
      res = pred (neighborsx, neighborsy, object$lastmoney [1])
    }
    return (res)
  }
setMethod ("predict", "maxnn", function (object, ...) predict.maxnn (object, ...))

#######################################################################################################
# KFNR (RÉGRESSION AVEC K-FARTHEST NEIGHBORS)
#######################################################################################################

setClass ("kfnr", representation (train = "data.frame", target = "vector", lastmoney = "vector", k = "numeric"))

KFNR <-
  function (train, target, lastmoney, k = 3, ...)
  {
    res = list (train = train, target = target, lastmoney = lastmoney, k = k)
    class (res) = "kfnr"
    return (res)
  }

predict.kfnr <-
  function (object, test, pred = average, distance = deuclid, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      train = object$train [, -1]
      ttest = test [-1]
      if (is.vector (train))
        train = data.frame (matrix (train, ncol = 1))
      distances = distance (train, ttest)
      ranks = rank (-unlist (distances), ties.method = "min")
      neighbors = which (ranks <= object$k)
      neighborsx = (object$lastmoney [-1]) [neighbors]
      neighborsy = object$target [neighbors]
      res = pred (neighborsx, neighborsy, object$lastmoney [1])
    }
    return (res)
  }
setMethod ("predict", "kfnr", function (object, ...) predict.kfnr (object, ...))

#######################################################################################################
# KRNR (RÉGRESSION AVEC K-RANDOM NEIGHBORS)
#######################################################################################################

setClass ("krnr", representation (train = "data.frame", target = "vector", lastmoney = "vector", k = "numeric"))

KRNR <-
  function (train, target, lastmoney, k = 3, ...)
  {
    res = list (train = train, target = target, lastmoney = lastmoney, k = k)
    class (res) = "krnr"
    return (res)
  }

predict.krnr <-
  function (object, test, pred = average, distance = deuclid, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      ttest = test [-1]
      n = nrow (object$train)
      neighbors = sample (1:n, object$k)
      neighborsx = (object$lastmoney [-1]) [neighbors]
      neighborsy = object$target [neighbors]
      res = pred (neighborsx, neighborsy, object$lastmoney [1])
    }
    return (res)
  }
setMethod ("predict", "krnr", function (object, ...) predict.krnr (object, ...))

#######################################################################################################
# KNNRCLUST (RÉGRESSION AVEC K-NN AVEC CLUSTERING)
#######################################################################################################

setClass ("knnrclust", representation (train = "data.frame", centers = "data.frame", cluster = "vector", target = "vector", lastmoney = "vector", k = "numeric", kclust = "numeric"))

KNNRCLUST <-
  function (train, target, lastmoney, centers, cluster, k = 3, kclust = 1, ...)
  {
    res = list (train = train, target = target, lastmoney = lastmoney, centers = centers, cluster = cluster, k = k, kclust = kclust)
    class (res) = "knnrclust"
    return (res)
  }

predict.knnrclust <-
  function (object, test, pred = average, distance = deuclid, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      train = object$centers
      if (is.vector (train))
        train = data.frame (matrix (train, ncol = 1))
      ttest = test [-1]
      distances = distance (train, ttest)
      ranks = rank (unlist (distances), ties.method = "min")
      nearestclusters = which (ranks <= object$kclust)
      clusterbool = object$cluster %in% nearestclusters
      train = object$train [clusterbool, -1]
      if (is.vector (train))
        train = data.frame (matrix (train, ncol = 1))
      distances = distance (train, ttest)
      ranks = rank (unlist (distances), ties.method = "min")
      neighbors = which (ranks <= object$k)
      neighborsx = ((object$lastmoney [-1]) [clusterbool]) [neighbors]
      neighborsy = (object$target [clusterbool]) [neighbors]
      res = pred (neighborsx, neighborsy, object$lastmoney [1])
      
      assign ("nbdist", nbdist + object$kclust + sum (clusterbool), envir = .GlobalEnv)
      assign ("nb.nbdist", nb.nbdist + 1, envir = .GlobalEnv)
    }
    return (res)
  }
setMethod ("predict", "knnrclust", function (object, ...) predict.knnrclust (object, ...))

allkm = function (time, goal, money, backers, clustering = "kmeans")
{
  for (nbclusters in seq (5, 30, 5))
    for (kclust in 1:(nbclusters - 1))
    {
      filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/pred.knn.", clustering, nbclusters,
                        ".k", kclust, ".data", sep = "")
      if (!file.exists (filename))
      {
        cat ("k\"=", nbclusters, ", k'=", kclust, "\n", sep = "")
        pred = crossvalidation (KNNRCLUST, extract.lastmoney, time, goal, money, backers, step = 10, pred = coeffmedian, k = 16,
                                nbclusters = nbclusters, kclust = kclust, clustering = clustering) [[1]]
        save.predictions (pred, file = paste ("pred.knn.", clustering , nbclusters, ".k", kclust, sep = ""))
      }
    }
}

#######################################################################################################
# RECHERCHE DU MEILLEUR K
#######################################################################################################

selectk = function (ks.time, ks.goal, ks.money, ks.backers)
{
  ks = 1:33
  for (k in ks)
  {
    filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/pred.knn.k", k, ".data", sep = "")
    if (!file.exists (filename))
    {
      print (k)
      pred = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = k) [[1]]
      save.predictions (pred, file = paste ("pred.knn.k", k, sep = ""))
    }
  }
}

#######################################################################################################
# NAIVELAST (PRÉDICTION NAÏVE UTILISANT LE DERNIER ÉTAT CONNU)
#######################################################################################################

setClass ("naivelast", representation ())

NAIVELAST <-
  function (train, target, ...)
  {
    res = list ()
    class (res) = "naivelast"
    return (res)
  }

predict.naivelast <-
  function (object, test, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      res = test [2]
    }
    return (res)
  }
setMethod ("predict", "naivelast", function (object, ...) predict.naivelast (object, ...))

#######################################################################################################
# NAIVETREND (PRÉDICTION NAÏVE UTILISANT LA PROPORTIONNALITÉ)
#######################################################################################################

setClass ("naivetrend", representation ())

NAIVETREND <-
  function (train, target, ...)
  {
    res = list ()
    class (res) = "naivetrend"
    return (res)
  }

predict.naivetrend <-
  function (object, test, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      res = 100 * (test [2] / test [1])
    }
    return (res)
  }
setMethod ("predict", "naivetrend", function (object, ...) predict.naivetrend (object, ...))

#######################################################################################################
# REGRESSION POLYNOMIALE (SUR UNE SÉRIE TEMPORELLE)
#######################################################################################################

library (mda)
setClass ("tspolyreg", representation (degree = "numeric"))

TSPOLYREG <-
  function (train, target, degree = 2, ...)
  {
    res = list (degree = degree)
    class (res) = "tspolyreg"
    return (res)
  }

predict.tspolyreg <-
  function (object, test, tune = F, featurestep = 1, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      ts = c (0, unlist (test [-1]))
      x = c (0, as.numeric (names (test [-1])))
      model = polyreg (x = x, y = ts, degree = object$degree)
      res = predict (model, 100)
    }
    return (res)
  }
setMethod ("predict", "tspolyreg", function (object, ...) predict.tspolyreg (object, ...))

#######################################################################################################
# ARIMA
#######################################################################################################

library (forecast)
setClass ("arimareg", representation ())

ARIMA <-
  function (train, target, ...)
  {
    res = list ()
    class (res) = "arimareg"
    return (res)
  }

predict.arimareg <-
  function (object, test, tune = F, featurestep = 1, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      ts = c (0, unlist (test [-1]))
      size = length (ts)
      model = auto.arima (data.frame (matrix (ts, ncol = 1)))
      res = tail (forecast (model, 1000 / featurestep - size + 1)$mean, 1)
    }
    return (res)
  }
setMethod ("predict", "arimareg", function (object, ...) predict.arimareg (object, ...))

#######################################################################################################
# REGRESSION LINÉAIRE (SUR PLUSIEURS SÉRIES TEMPORELLES)
#######################################################################################################

setClass ("flinreg", representation ())

FLINREG <-
  function (train, target, ...)
  {
    res = list (train = train, target = target)
    class (res) = "flinreg"
    return (res)
  }

predict.flinreg <-
  function (object, test, tune = F, ...)
  {
    res = NULL
    if (tune)
      res = emptyparams ()
    else
    {
      train = object$train [, -1]
      ttest = test [-1]
      if (is.vector (train))
      {
        train = data.frame (matrix (train, ncol = 1))
        colnames (train) = "X"
        ttest = data.frame (matrix (ttest, ncol = 1))
        colnames (ttest) = "X"
      }
      data = cbind.data.frame (train, Y = object$target)
      model = lm (Y~., data)
      n = names (ttest)
      ttest = data.frame (matrix (ttest, nrow = 1))
      colnames (ttest) = n
      res = predict (model, ttest)
    }
    return (res)
  }
setMethod ("predict", "flinreg", function (object, ...) predict.flinreg (object, ...))

#######################################################################################################
# RÉÉCHANTILLONAGE DES DONNÉES
#######################################################################################################

uniformity = function (v) stdev (diff (v))
unif1 = 0
nbunif1 = 0
unif2 = 0
nbunif2 = 0

rsize = function (d, avsize = 100, minsize = 10)
{
  nc = NULL
  nr = NULL
  if (is.vector (d))
  {
    nc = length (d)
    nr = 1
  }
  {
    nc = ncol (d)
    nr = nrow (d)
  }
  res = sample (avsize - minsize, nr * 2, replace = T)
  res = res [1:nr] + res [(nr + 1):(2 * nr)]
  res = minsize + res - 1
  return (res)
}

rstates1 = function (size)
{
  base = round (seq (10, 1000, length.out = size + 2) [-c (1, size + 2)])
  spacing = floor (mean (diff (base)) / 2)
  noise = sample (spacing, size * 2, replace = T)
  noise = noise [1:size] + noise [(size + 1):(2 * size)]
  noise = noise - spacing - 1
  res = c (1, 10, base + noise, 1000)
  assign ("unif1", unif1 + uniformity (res), envir = .GlobalEnv)
  assign ("nbunif1", nbunif1 + 1, envir = .GlobalEnv)
  return (res)
}

rstates2 = function (size)
{
  base = sample (11:999, size, replace = F)
  res = c (1, 10, sort (base), 1000)
  assign ("unif2", unif2 + uniformity (res), envir = .GlobalEnv)
  assign ("nbunif2", nbunif2 + 1, envir = .GlobalEnv)
  return (res)
}

interpol = function (values, states, state)
{
  res = NULL
  if (state %in% states)
    res = values [states [states == state]]
  else
  {
    previ = max (states [states < state])
    nexti = min (states [states > state])
    dif = nexti - previ
    prevc = (nexti - state) / dif
    nextc = (state - previ) / dif
    res = prevc * values [previ] + nextc * values [nexti]
  }
  return (res)
}

interpmin = function (values, states, state)
{
  index = max (states [states <= state])
  return (values [index])
}

sampleline = function (v, frstates = rstates1, interp = interpol)
{
  states = frstates (v [1])
  return (sapply (1:(length (v) - 1), interp, values = v [-1], states = states))
}

rsample = function (d, avsize = 100, minsize = 10, frstates = rstates1, interp = interpol)
{
  size = rsize (d, avsize, minsize)
  newd = t (apply (cbind (size, d), 1, sampleline, frstates = frstates, interp = interp))
  colnames (newd) = colnames (d)
  rownames (newd) = rownames (d)
  return (newd)
}

#######################################################################################################
# PROTOCOLE D'ÉVALUATION
#######################################################################################################

get.learning.set = function (ks.time, index)
{
  threshold = ks.time [index, "Start"]
  return (which (ks.time [, "Deadline"] < threshold))
}

library (lubridate)
library (flexclust)
crossvalidation = function (method, extract.features,
                            time, goal, money, backers,
                            minsize = 1000, maxsize = 1000,
                            step = 50, clustering = "kmeans", nbclusters = 1,
                            resample = NULL,
                            ...)
{
  states = seq (step, 1000 - step, step)
  size = nrow (time)
  targets = NULL
  predictions = NULL
  computation.time = NULL
  progress = 0
  endp = size
  debut = Sys.time ()
  print (format (debut, "Lancé le %A %d %B %Y à %H:%M:%S"))
  pb = txtProgressBar(style = 3)
  for (i in 1:size)
  {
    learning.set = get.learning.set (time, i)
    if (length (learning.set) >= minsize)
    {
      if (length (learning.set) >= maxsize)
        learning.set = tail (learning.set, maxsize)
      learning.set = c (i, learning.set)
      targets = c (targets, money [i, 1000])
      learning.time = time [learning.set, ]
      learning.goal = data.frame (matrix (goal [learning.set, ], ncol = 1))
      learning.money = money [learning.set, ]
      y = learning.money [-1, 1000]
      if (!is.null (resample))
      {
        learning.money [1, ] = sampleline (c (rsize (learning.money [1, ]), unlist (learning.money [1, ])),
                                           frstates = resample, interp = interpmin)
        learning.money [-1, ] = rsample (learning.money [-1, ],
                                         frstates = resample, interp = interpol)
      }
      learning.backers = backers [learning.set, ]
      preds = NULL
      cluster = NULL
      centers = NULL
      if (nbclusters > 1)
      {
        km = flexclust::kcca (learning.money [-1, seq (100, 1000, 100)], nbclusters, family = kccaFamily (clustering))
        cluster = clusters (km)
        centers = cbind (Cluster = cluster, learning.money [-1, ])
        centers = aggregate (. ~ Cluster, data = centers, get (substr (clustering, 2, nchar (clustering) - 1))) [, -1]
      }
      for (state in states)
      {
        start = Sys.time ()
        features = extract.features (learning.time, learning.goal, learning.money, learning.backers, states, state, ...)
        lastmoney = xlastmoney (learning.money, state)
        fcenters = NULL
        if (nbclusters > 1)
          fcenters = extract.features (learning.time, learning.goal, centers, learning.backers, states, state, ...)
        current = features [1, ]
        features = features [-1, ]
        if (is.vector (features))
          features = data.frame (matrix (features, ncol = 1))
        names (current) = colnames (features)
        model = method (train = features, target = y, centers = fcenters, cluster = cluster, lastmoney = lastmoney, ...)
        prediction = predict (model, current, ...)
        preds = c (preds, unlist (prediction))
        end = Sys.time ()
        computation.time = c (computation.time, end - start)
      }
      predictions = rbind (predictions, preds)
      progress = progress + 1
      setTxtProgressBar(pb, progress / endp)
    }
    else
      endp = endp - 1
  }
  progress = c (0, as.numeric (colnames (money) [states]), 100)
  res = cbind (rep (0, nrow (predictions)), predictions, targets)
  colnames (res) = progress
  rownames (res) = NULL
  res = list (res, mean (computation.time))
  print (paste ("Durée :", as.duration (Sys.time () - debut)))
  return (res)
}

#######################################################################################################
# EXTRACTION DE DONNÉES POUR LES ANALYSES
#######################################################################################################

extract = function (time, goal, money, backers, minsize = 1000)
{
  size = nrow (time)
  res = NULL
  for (i in 1:size)
  {
    learning.set = get.learning.set (time, i)
    if (length (learning.set) >= minsize)
    {
      row = c (time [i, 1], time [i, 2] - time [i, 1], goal [i, 1], money [i, 10], backers [i, 1000],
               ifelse (backers [i, 1000] == 0, 0, money [i, 1000] / backers [i, 1000]), mean (unlist (money [i, ])), money [i, 1000])
      res = rbind (res, row)
    }
  }
  colnames (res) = c ("Starting time", "Duration", "Goal", "Impulse", "Backers", "Average pledge", "AUC", "Final money")
  rownames (res) = NULL
  return (res)
}

#######################################################################################################
# ÉCRITURE DES RÉSULTATS
#######################################################################################################

save.predictions = function (pred, file = NULL)
{
  ffile = file
  if (is.null (file))
    ffile = deparse (substitute (pred))
  filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/", ffile, ".data", sep = "")
  write.table (pred, file = filename, row.names = F, col.names = T)
}

save.time = function (size, time, file = NULL)
{
  ffile = file
  if (is.null (file))
    ffile = deparse (substitute (time))
  filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/", ffile, ".data", sep = "")
  write.table (cbind (Size = sizes, Time = time), file = filename, row.names = F, col.names = T)
}

save.nbdist = function (size, nbdist, file = NULL)
{
  ffile = file
  if (is.null (file))
    ffile = deparse (substitute (nbdist))
  filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/", ffile, ".data", sep = "")
  write.table (cbind (Size = sizes, Nbdist = nbdist), file = filename, row.names = F, col.names = T)
}

#######################################################################################################
# LECTURE DES DONNÉES
#######################################################################################################

ks.time = read.table ("/home/blansche/Boulot/Recherche/Data/Kickstarter/ks.time.data", row.names = 1)
ks.goal = read.table ("/home/blansche/Boulot/Recherche/Data/Kickstarter/ks.goal.data", row.names = 1)
ks.money = read.table ("/home/blansche/Boulot/Recherche/Data/Kickstarter/ks.money.data", row.names = 1) * 100
ks.backers = read.table ("/home/blansche/Boulot/Recherche/Data/Kickstarter/ks.backers.data", row.names = 1)
reorder = order (ks.time [, 1])
ks.time = ks.time [reorder, ]
colnames (ks.time) = c ("Start", "Deadline")
ks.goal = data.frame (matrix (ks.goal [reorder, ], ncol = 1))
colnames (ks.goal) = "Goal"
ks.money = ks.money [reorder, ]
colnames (ks.money) = seq (0, 999) / 9.99
ks.backers = ks.backers [reorder, ]
colnames (ks.backers) = seq (0, 999) / 9.99
ks.dollars = sweep (ks.money, 1, ks.goal [, 1], "*")
ks.avpledge = ks.money / ks.backers
ks.avpledge [is.na (ks.avpledge)] = 0

ex = extract (ks.time, ks.goal, ks.money, ks.backers)
write.table (ex, file = "/home/blansche/Boulot/Recherche/Resultats/Kickstarter/extract.data", row.names = F, col.names = T)

#######################################################################################################
# TESTS DE RÉGRESSION
#######################################################################################################

# NAIVE TREND ET AUTRES MÉTHODES "CLASSIQUES"
pred.naivelast = crossvalidation (NAIVELAST, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10) [[1]]
save.predictions (pred.naivelast)
pred.naivetrend = crossvalidation (NAIVETREND, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10) [[1]]
save.predictions (pred.naivetrend)
pred.tslinreg10 = crossvalidation (TSLINREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 100, featurestep = 100) [[1]]
save.predictions (pred.tslinreg10)
pred.tslinreg100 = crossvalidation (TSLINREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 10) [[1]]
save.predictions (pred.tslinreg100)
pred.tslinreg1000 = crossvalidation (TSLINREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 1) [[1]]
save.predictions (pred.tslinreg1000)
pred.tspoly2reg10 = crossvalidation (TSPOLYREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 100, featurestep = 100, degree = 2) [[1]]
save.predictions (pred.tspoly2reg10)
pred.tspoly2reg100 = crossvalidation (TSPOLYREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 10, degree = 2) [[1]]
save.predictions (pred.tspoly2reg100)
pred.tspoly2reg1000 = crossvalidation (TSPOLYREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 1, degree = 2) [[1]]
save.predictions (pred.tspoly2reg1000)
pred.tspoly3reg10 = crossvalidation (TSPOLYREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 100, featurestep = 100, degree = 3) [[1]]
save.predictions (pred.tspoly3reg10)
pred.tspoly3reg100 = crossvalidation (TSPOLYREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 10, degree = 3) [[1]]
save.predictions (pred.tspoly3reg100)
pred.tspoly3reg1000 = crossvalidation (TSPOLYREG, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 1, degree = 3) [[1]]
save.predictions (pred.tspoly3reg1000)
pred.arima10 = crossvalidation (ARIMA, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 100, featurestep = 100) [[1]]
save.predictions (pred.arima10)
pred.arima100 = crossvalidation (ARIMA, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 10) [[1]]
save.predictions (pred.arima100)
pred.arima1000 = crossvalidation (ARIMA, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers, step = 10, featurestep = 1) [[1]]
save.predictions (pred.arima1000)

# RECHERCHE DU MEILLEUR K
selectk (ks.time, ks.goal, ks.money, ks.backers)

# K-NN, DERNIER ÉTAT, VARIATION SUR LA MÉTHODE D'ADAPTATION
pred.knn.last.mean = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = average, k = 16) [[1]]
save.predictions (pred.knn.last.mean)
pred.knn.last.shift.mean = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = shift, k = 16) [[1]]
save.predictions (pred.knn.last.shift.mean)
pred.knn.last.coeff.mean = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeff, k = 16) [[1]]
save.predictions (pred.knn.last.coeff.mean)
pred.knn.last.shift.coeff.mean = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = shiftcoeff, k = 16) [[1]]
save.predictions (pred.knn.last.shift.coeff.mean)
pred.knn.last.median = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = amedian, k = 16) [[1]]
save.predictions (pred.knn.last.median)
pred.knn.last.shift.median = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = shiftmedian, k = 16) [[1]]
save.predictions (pred.knn.last.shift.median)
pred.knn.last.coeff.median = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knn.last.coeff.median)
pred.knn.last.shift.coeff.median = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = shiftcoeffmedian, k = 16) [[1]]
save.predictions (pred.knn.last.shift.coeff.median)

# SÉLÉCTION DES VOISINS : TOUS, LES PLUS ÉLOIGNÉS, AU HASARD
pred.maxnn = crossvalidation (MAXNN, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian) [[1]]
save.predictions (pred.maxnn)
pred.kfn1 = crossvalidation (KFNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 1) [[1]]
save.predictions (pred.kfn1)
pred.kfn16 = crossvalidation (KFNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.kfn16)
pred.krn1 = crossvalidation (KRNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 1) [[1]]
save.predictions (pred.krn1)
pred.krn16 = crossvalidation (KRNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.krn16)

# K-NN SÉRIES COMPLÈTES, DISTANCE EUCLIDIENNE
pred.knneuclid10 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                    step = 100, featurestep = 100, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knneuclid10)
pred.knneuclid100 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                     step = 10, featurestep = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knneuclid100)
pred.knneuclid1000 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                      step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knneuclid1000)

# K-NN SÉRIES COMPLÈTES, DISTANCE EUCLIDIENNE (DONNÉES CENTRÉES ET RÉDUITES)
pred.knnseuclid10 = crossvalidation (KNNR, extract.scaledmoneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                     step = 100, featurestep = 100, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knnseuclid10)
pred.knnseuclid100 = crossvalidation (KNNR, extract.scaledmoneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                      step = 10, featurestep = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knnseuclid100)
pred.knnseuclid1000 = crossvalidation (KNNR, extract.scaledmoneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                       step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knnseuclid1000)

# K-NN SÉRIES COMPLÈTES, DISTANCE DE MAHALANOBIS
pred.knnmahalanobis10 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                         step = 100, featurestep = 100, pred = coeffmedian, k = 16, distance = dmahalanobis) [[1]]
save.predictions (pred.knnmahalanobis10)
pred.knnmahalanobis100 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                          step = 10, featurestep = 10, pred = coeffmedian, k = 16, distance = dmahalanobis) [[1]]
save.predictions (pred.knnmahalanobis100)
pred.knnmahalanobis1000 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                           step = 10, pred = coeffmedian, k = 16, distance = dmahalanobis) [[1]]
save.predictions (pred.knnmahalanobis1000)

# K-NN SÉRIES COMPLÈTES, DTW
pred.knndtw10 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                 step = 100, featurestep = 100, pred = coeffmedian, k = 16, distance = ddtw) [[1]]
save.predictions (pred.knndtw10)
pred.knndtw100 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                  step = 10, featurestep = 10, pred = coeffmedian, k = 16, distance = ddtw) [[1]]
save.predictions (pred.knndtw100)
pred.knndtw1000 = crossvalidation (KNNR, extract.moneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                   step = 10, pred = coeffmedian, k = 16, distance = ddtw) [[1]]
save.predictions (pred.knndtw1000)

# K-NN SÉRIES COMPLÈTES, DTW (DONNÉES CENTRÉES ET RÉDUITES)
pred.knnsdtw10 = crossvalidation (KNNR, extract.scaledmoneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                   step = 100, featurestep = 100, pred = coeffmedian, k = 16, distance = ddtw) [[1]]
save.predictions (pred.knnsdtw10)
pred.knnsdtw100 = crossvalidation (KNNR, extract.scaledmoneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                   step = 10, featurestep = 10, pred = coeffmedian, k = 16, distance = ddtw) [[1]]
save.predictions (pred.knnsdtw100)
pred.knnsdtw1000 = crossvalidation (KNNR, extract.scaledmoneyseries, ks.time, ks.goal, ks.money, ks.backers,
                                    step = 10, pred = coeffmedian, k = 16, distance = ddtw) [[1]]
save.predictions (pred.knnsdtw1000)

# K-NN AVEC DES SÉRIES INCOMPLÈTES IRRÉGULIÈRES
pred.knn.resample1 = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16, resample = rstates1) [[1]]
save.predictions (pred.knn.resample1)
pred.knn.resample2 = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16, resample = rstates2) [[1]]
save.predictions (pred.knn.resample2)
print (unif1 / nbunif1)
print (unif2 / nbunif2)
write.table (rbind (unif1, unif2),
             file = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/uniformity.data", sep = ""),
             row.names = F, col.names = T)

# K-NN AVEC SÉLECTION DE VARIABLES
multitest (ks.time, ks.goal, ks.money, ks.backers)

# PRÉDICTION DU NOMBRE DE BACKERS, DU NOMBRE DE $, DU PLEDGE MOYEN
pred.knn.backers = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.backers,
                                    ks.backers, step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knn.backers)
pred.knn.dollars = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.dollars,
                                    ks.backers, step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knn.dollars)
pred.knn.avpledge = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.avpledge,
                                    ks.backers, step = 10, pred = coeffmedian, k = 16) [[1]]
save.predictions (pred.knn.avpledge)

#######################################################################################################
# K-NN AVEC CLUSTERING
#######################################################################################################

# MAINTIEN DES PERFORMANCES DE PRÉDICTION
allkm (ks.time, ks.goal, ks.money, ks.backers, "kmeans")
allkm (ks.time, ks.goal, ks.money, ks.backers, "kmedians")

# TEMPS DE CALCUL
sizes = seq (1000, 15000, 1000)
time.knn = NULL
for (size in sizes)
{
  print (size)
  tmp = crossvalidation (KNNR, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16,
                         minsize = size, maxsize = size)
  time.knn = c (time.knn, tmp [[2]])
  save.time (sizes, time.knn)
}
time.knnkm = NULL
nbdist.knnkm = NULL
nbdist = 0
nb.nbdist = 0
for (size in sizes)
{
  print (paste ("Size:", size))
  nbdist = 0
  nb.nbdist = 0
  tmp = crossvalidation (KNNRCLUST, extract.lastmoney, ks.time, ks.goal, ks.money, ks.backers, step = 10, pred = coeffmedian, k = 16,
                         nbclusters = 30, kclust = 6,
                         minsize = size, maxsize = size)
  time.knnkm = c (time.knnkm, tmp [[2]])
  nbdist.knnkm = c (nbdist.knnkm, nbdist / nb.nbdist)
  print (paste ("Time:", tmp [[2]]))
  print (paste ("Nb. dist:", nbdist / nb.nbdist))
  save.time (sizes, time.knnkm)
  save.nbdist (sizes, nbdist.knnkm)
}

#######################################################################################################
# DIVERS
#######################################################################################################

stdev = function (v)
{
  m = mean (v)
  res = sqrt (mean ((v - m)^2))
  return (res)
}

#######################################################################################################
# CRITÈRES D'ÉVALUATION
#######################################################################################################

abs.error = function (predictions, targets, ...) abs (predictions - targets)

abs.sym.prop.error =  function (predictions, targets, ...)
{
  diff = abs.error (predictions, targets, ...)
  res = ifelse (diff == 0, 0, diff / ((abs (predictions) + abs (targets)) / 2))
  return (100 * res)
}

error = function (predictions, targets, ...) predictions - targets

sym.prop.error =  function (predictions, targets, ...)
{
  diff = error (predictions, targets, ...)
  res = ifelse (diff == 0, 0, diff / ((abs (predictions) + abs (targets)) / 2))
  return (100 * res)
}

evaluation.mse <-
  function (predictions, targets, ...) mean ((predictions - targets)^2)

evaluation.rmse <-
  function (predictions, targets, ...) sqrt (mean ((predictions - targets)^2))

evaluation.r2 <-
  function (predictions, targets, ...) 1 - ((sum ((predictions - targets)^2) / sum ((targets - mean (targets))^2)))

evaluation.mae <-
  function (predictions, targets, nq = 4, ...)
  {
    tmp = abs.error (predictions, targets, ...)
    if (!all (is.na (predictions)))
    {
      q = quantile (tmp, seq (0, 1, 1 / nq))
      res = c (mean (tmp), stdev (tmp), q [2], q [nq])
    }
    else
      res = c (mean (tmp), stdev (tmp))
    return (res)
  }

evaluation.smape <-
  function (predictions, targets, nq = 4, ...)
  {
    tmp = abs.sym.prop.error (predictions, targets, ...)
    if (!all (is.na (predictions)))
    {
      q = quantile (tmp, seq (0, 1, 1 / nq))
      res = c (mean (tmp), stdev (tmp), q [2], q [nq])
    }
    else
      res = c (mean (tmp), stdev (tmp))
    return (res)
  }

#######################################################################################################
# GRAPHIQUES, STATISTIQUES, ETC.
#######################################################################################################

evaluate.results = function (predictions,
                             measure = c ("mae", "smape", "r2", "mse", "rmse", "accuracy", "precision", "recall", "specificity"),
                             scale = NULL, nq = 4, ...)
{
  ylab = ""
  if (measure [1] == "r2")
  {
    measure = evaluation.r2
    ylab = "R²"
  }
  else if (measure [1] == "mae")
  {
    measure = evaluation.mae
    ylab = "MAE"
  }
  else if (measure [1] == "smape")
  {
    measure = evaluation.smape
    ylab = "sMAPE"
  }
  else if (measure [1] == "mse")
  {
    measure = evaluation.mse
    ylab = "MSE"
  }
  else if (measure [1] == "rmse")
  {
    measure = evaluation.rmse
    ylab = "RMSE"
  }
  else if (measure [1] == "toto1")
  {
    measure = evaluation.toto1
  }
  else if (measure [1] == "toto2")
  {
    measure = evaluation.toto2
    ylab = "toto2"
  }
  else if (measure [1] == "toto3")
  {
    measure = evaluation.toto3
    ylab = "toto3"
  }
  else if (measure [1] == "toto4")
  {
    measure = evaluation.toto4
    ylab = "toto4"
  }
  else if (measure [1] == "toto5")
  {
    measure = evaluation.toto5
    ylab = "toto5"
  }
  else if (measure [1] == "accuracy")
  {
    measure = evaluation.accuracy
    ylab = "Accuracy"
  }
  else if (measure [1] == "precision")
  {
    measure = evaluation.precision
    ylab = "Precision"
  }
  else if (measure [1] == "recall")
  {
    measure = evaluation.recall
    ylab = "Recall"
  }
  else if (measure [1] == "specificity")
  {
    measure = evaluation.specificity
    ylab = "Specificity"
  }
  evolution = NULL
  sdevolution = NULL
  q1evolution = NULL
  q3evolution = NULL
  pred = predictions
  if (!is.null (scale))
  {
    pred = pred / 100
    pred = sweep (pred, 1, scale, "*")
  }
  nstates = ncol (predictions)
  for (i in 2:(nstates - 1))
  {
    eval = measure (pred [, i], pred [, nstates], nq = nq, ...)
    evolution = c (evolution, eval [1])
    if (length (eval) > 1)
    {
      sdevolution = c (sdevolution, eval [2])
      q1evolution = c (q1evolution, eval [3])
      q3evolution = c (q3evolution, eval [4])
    }
  }
  res = cbind (as.numeric (colnames (predictions)) [2:(nstates - 1)], evolution, sdevolution, q1evolution, q3evolution)
  if (ncol (res) == 2)
    colnames (res) = c ("Time (%)", ylab)
  else
    colnames (res) = c ("Time (%)", ylab, paste (ylab, "(st. dev.)"), paste (ylab, "(Q1)"), paste (ylab, "(Q3)"))
  rownames (res) = NULL
  return (res)
}

evaluate.allresults = function (measure = c ("mae", "smape", "r2", "mse", "rmse", "accuracy", "precision", "recall", "specificity"),
                                predictions = NULL, ...)
{
  pred = NULL
  if (is.null (predictions))
    pred = list (...)
  else
    pred = predictions
  eval = NULL
  n = 0
  pb = txtProgressBar(style = 3)
  progress = 0
  maxp = length (pred)
  for (p in pred)
  {
    if (!is.null (p))
    {
      e = evaluate.results (p, measure)
      eval = rbind (eval, e [, 2])
      n = n + 1
      progress = progress + 1
      setTxtProgressBar(pb, progress / maxp)
    }
  }
  colnames (eval) = colnames (pred [[1]]) [2:100]
  rownames (eval) = 1:n
  return (eval)
}

compare.student = function (evaluations, i, measure)
{
  nb = 0
  l = nrow (evaluations)
  for (j in 1:l)
  {
    if ((j != i) && (significantly.better (eval1 = evaluations [i, ], eval2 = evaluations [j, ], measure, p = .05) [[1]]))
      nb = nb + 1
  }
  return (100 * nb / (l - 1))
}

compare.results = function (measure = c ("mae", "smape", "r2", "mse", "rmse", "accuracy", "precision", "recall", "specificity"),
                            predictions = NULL, ...)
{
  coeff = 1
  best = 1
  if (measure %in% c("accuracy", "precision", "recall"))
  {
    coeff = -1
    best = length (predictions)
  }
  evaluations = evaluate.allresults (measure, predictions = predictions, ...)
  ranks = apply (evaluations, 2, rank, ties.method = "min")
  average = coeff * apply (evaluations, 1, mean)
  percentage = -apply (ranks, 1, FUN = function (v) (100 * length (which (v == best)) / 99))
  meanrank = coeff * apply (ranks, 1, mean)
  medianrank = coeff * apply (ranks, 1, median)
  stud = NULL
  for (i in 1:(nrow (evaluations)))
  {
    stud = c (stud, compare.student (evaluations, i, measure))
  }
  res = rbind (average, percentage, meanrank, medianrank, -1 * stud)
  rownames (res) = c ("Average", "Percentage", "Mean", "Median", "Student")
  colnames (res) = rownames (evaluations)
  return (res)
}

ploteval = function (measure = c ("mae", "smape", "r2", "mse", "rmse", "accuracy", "precision", "recall", "specificity"), scale = NULL,
                     ymin = NULL, ymax = NULL, labels, add = FALSE, legend = TRUE, n = 0, threshold = 100, predictions = NULL,
                     line = c ("mean", "std", "q"), alpha = .2, ...)
{
  pred = NULL
  if (is.null (predictions))
    pred = list (...)
  else
    pred = predictions
  ylab = NULL
  lpos = NULL
  yymax = NULL
  if (measure [1] == "r2")
  {
    lpos = "bottomright"
    ylab = "R²"
    yymax = 1
  }
  else if (measure [1] == "mae")
  {
    lpos = "topright"
    ylab = "MAE"
    yymax = 100
  }
  else if (measure [1] == "smape")
  {
    lpos = "topright"
    ylab = "sMAPE"
    yymax = 100
  }
  else if (measure [1] == "mse")
  {
    lpos = "topright"
    ylab = "MSE"
    yymax = 100
  }
  else if (measure [1] == "rmse")
  {
    lpos = "topright"
    ylab = "RMSE"
    yymax = 100
  }
  else if (measure [1] == "toto1")
  {
    lpos = "topright"
    ylab = "toto1"
    yymax = 100
  }
  else if (measure [1] == "toto2")
  {
    lpos = "topright"
    ylab = "toto2"
    yymax = 100
  }
  else if (measure [1] == "toto3")
  {
    lpos = "topright"
    ylab = "toto3"
    yymax = 100
  }
  else if (measure [1] == "toto4")
  {
    lpos = "topright"
    ylab = "toto4"
    yymax = 100
  }
  else if (measure [1] == "toto5")
  {
    lpos = "topright"
    ylab = "toto5"
    yymax = 100
  }
  else if (measure [1] == "accuracy")
  {
    lpos = "bottomright"
    ylab = "Accuracy"
    yymax = 1
  }
  else if (measure [1] == "precision")
  {
    lpos = "bottomright"
    ylab = "Precision"
    yymax = 1
  }
  else if (measure [1] == "recall")
  {
    lpos = "bottomright"
    ylab = "Recall"
    yymax = 1
  }
  else if (measure [1] == "specificity")
  {
    lpos = "topright"
    ylab = "Specificity"
    yymax = 1
  }
  if (is.null (ymax))
    ymax = yymax
  if (is.null (ymin))
    ymin = 0
  if (!add)
    plot (-1, -1,
          xlim = c (0, 100), ylim = c (ymin, ymax),
          xaxs = "i", yaxs = "i",
          col = 0,
          bty = "o",
          xlab = "Time (%)", ylab = ylab,
          cex.axis = 1.5, cex.lab = 1.5, panel.first = grid ())
  nb = length (pred)
  col = NULL
  lty = NULL
  if (nb <= 7)
  {
    col = c ("red", "blue", "forestgreen", "purple", "orange", "cyan3", "limegreen")
    lty = 1:7
  }
  else
  {
    col = rep (rgb (0, 0, 0, alpha), nb)
    lty = rep (1, nb)
  }
  check = rep (T, length (pred))
  for (i in 1:nb)
    if (!is.null (pred [[i]]))
    {
      nq = 4
      if (startsWith (line [1], "q"))
        nq = as.numeric (substring (line, 2))
      eval = evaluate.results (pred [[i]], measure = measure, threshold, scale = scale, nq = nq, ...)
      lines (eval [, 1:2], col = col [i + n], lty = lty [i + n], lwd = 3)
      if ((line [1] == "std") && (ncol (eval) > 2))
      {
        lines (cbind (eval [, 1], eval [, 2] + eval [, 3]), col = col [i + n], lty = lty [i + n], lwd = 1)
        lines (cbind (eval [, 1], eval [, 2] - eval [, 3]), col = col [i + n], lty = lty [i + n], lwd = 1)
      }
      if ((startsWith (line [1], "q")) && (ncol (eval) > 2))
      {
        lines (eval [, c (1, 4)], col = col [i + n], lty = lty [i + n], lwd = 1)
        lines (eval [, c (1, 5)], col = col [i + n], lty = lty [i + n], lwd = 1)
      }
    }
  else
    check [i] = F
  if (legend)
    legend (lpos, lty = (1:nb) [check], col = col [check],
            legend = labels [check], lwd = 3, cex = 1.5, bg = "white")
  nbwarnings = sum (!check)
  if (nbwarnings == 1)
    warning ("1 missing result")
  else if (nbwarnings > 1)
    warning (paste (nbwarnings, "missing results"))
}

plotevalsf = function (pred, measure = c ("mae", "smape", "r2", "mse", "rmse", "accuracy", "precision", "recall", "specificity"),
                       ymin = NULL, ymax = NULL, labels, ...)
{
  nstates = ncol (pred)
  success = pred [, nstates] >= 100
  pred.success = pred [success, ]
  pred.failed = pred [!success, ]
  labels = c ("All", "Successful", "Failed")
  ploteval (measure, ymin, ymax, labels = labels, l1 = pred, l2 = pred.success, l3 = pred.failed, ...)
}

#######################################################################################################
# RECHERCHE EXHAUSTIVE POUR LA SÉLECTION DE VARIABLES
#######################################################################################################

nextSelect = function (select)
{
  res = select
  pos = 1
  res [pos] = !res [pos]
  while (!res [pos])
  {
    pos = pos + 1
    res [pos] = !res [pos]
  }
  return (res)
}

selecttofile = function (select)
{
  core = paste (ifelse (select, 1, 0), collapse = "")
  res = paste ("pred", core, sep = ".")
  return (res)
}

selecttoname = function (select)
{
  res = ""
  if (select [1])
    res = paste (res, "M", sep = "")
  if (select [2])
    res = paste (res, "S", sep = "")
  if (select [3])
    res = paste (res, "C", sep = "")
  if (select [4])
    res = paste (res, "I", sep = "")
  if (select [5])
    res = paste (res, "B", sep = "")
  if (select [6])
    res = paste (res, "D", sep = "")
  if (select [7])
    res = paste (res, "G", sep = "")
  if (select [8])
    res = paste (res, "A", sep = "")
  return (res)
}

load.names = function ()
{
  res = NULL
  select = rep (F, 8)
  end = F
  while (!end)
  {
    select = nextSelect (select)
    filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/", selecttofile (select), ".data", sep = "")
    if (file.exists (filename))
      res = c (res, selecttoname (select))
    end = all (select)
  }
  return (res)
}

load.multitest = function ()
{
  res = NULL
  select = rep (F, 8)
  end = F
  pb = txtProgressBar(style = 3)
  nbselect = 2^length (select) - 1
  progress = 0
  while (!end)
  {
    select = nextSelect (select)
    pred = load.predictions (selecttofile (select))
    if (!is.null (pred))
      res = c (res, list (pred))
    end = all (select)
    progress = progress + 1
    setTxtProgressBar(pb, progress / nbselect)
  }
  return (res)
}

#######################################################################################################
# TEST DE DIFFÉRENCE SIGNIFICATIVE ENTRE LES PRÉDICTIONS
#######################################################################################################

normal = function (eval1, eval2, p = .01, details = 0)
{
  return (shapiro.test (eval1 - eval2)$p.value < p)
}

student = function (eval1, eval2, p = .01, details = 0)
{
  return (t.test (eval1 - eval2, alternative = "less")$p.value)
}

significantly.better = function (pred1 = NULL, pred2 = NULL, eval1 = NULL, eval2 = NULL, measure = c ("smape", "mae"), p = .01, details = 0)
{
  ev1 = NULL
  ev2 = NULL
  if (is.null (eval1))
  {
    ev1 = evaluate.allresults (measure, l1 = pred1)
    ev2 = evaluate.allresults (measure, l1 = pred2)
  }
  else
  {
    ev1 = eval1
    ev2 = eval2
  }
  n = normal (ev1, ev2, p, details)
  s = student (ev1, ev2, p, details)
  valid = (s < p) && n
  res = c (list (valid), list (s))
  if (details >= 1)
  {
    print ("")
    print (n)
    print (s)
    print (res)
  }
  if (details >= 2)
  {
    v = c (ev1, ev2)
    xmin = min (v)
    xmax = max (v)
    hist (ev1, breaks = 50, col = rgb (1, 0, 0, .5), xlim = c (xmin, xmax))
    hist (ev2, breaks = 50, col = rgb (0, 0, 1, .5), add = T)
    v = ev1 - ev2
    xmin = min (v)
    xmax = max (v)
    hist (v, breaks = 50, col = rgb (1, 0, 0, .5), xlim = c (xmin, xmax))
  }
  return (res)
}

#######################################################################################################
# CHARGEMENT DES RÉSULTATS
#######################################################################################################

load.predictions = function (file)
{
  filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/", file, ".data", sep = "")
  pred = NULL
  if (file.exists (filename))
    pred = read.table (filename, header = T, check.names = F)
  return (pred)
}

load.time = function (file)
{
  filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/time.", file, ".data", sep = "")
  time = NULL
  if (file.exists (filename))
    time = read.table (filename, header = T, check.names = F)
  return (time)
}

load.size = function (file)
{
  filename = paste ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/nbdist.", file, ".data", sep = "")
  time = NULL
  if (file.exists (filename))
    time = read.table (filename, header = T, check.names = F)
  return (time)
}

source ("/home/blansche/Boulot/Recherche/Code/R/Kickstarter/evaluate.reg4.core.R")

#######################################################################################################
# TESTS DE RÉGRESSION
#######################################################################################################

# NAIVE TREND ET AUTRES MÉTHODES "CLASSIQUES"
pred.naivelast = load.predictions ("pred.naivelast")
pred.naivetrend = load.predictions ("pred.naivetrend")
pred.tslinreg1000 = load.predictions ("pred.tslinreg1000")
pred.tslinreg100 = load.predictions ("pred.tslinreg100")
pred.tslinreg10 = load.predictions ("pred.tslinreg10")
pred.tspoly2reg1000 = load.predictions ("pred.tspoly2reg1000")
pred.tspoly2reg100 = load.predictions ("pred.tspoly2reg100")
pred.tspoly2reg10 = load.predictions ("pred.tspoly2reg10")
pred.tspoly3reg1000 = load.predictions ("pred.tspoly3reg1000")
pred.tspoly3reg100 = load.predictions ("pred.tspoly3reg100")
pred.tspoly3reg10 = load.predictions ("pred.tspoly3reg10")
pred.arima1000 = load.predictions ("pred.arima1000")
pred.arima100 = load.predictions ("pred.arima100")
pred.arima10 = load.predictions ("pred.arima10")
ploteval (measure = "smape", l1 = pred.tslinreg10, l2 = pred.tslinreg100, l3 = pred.tslinreg1000,
          labels = c ("Linear 10", "Linear 100", "Linear 1000"))
ploteval (measure = "mae", l1 = pred.tslinreg10, l2 = pred.tslinreg100, l3 = pred.tslinreg1000,
          labels = c ("Linear 10", "Linear 100", "Linear 1000"))
ploteval (measure = "smape", l1 = pred.tspoly2reg10, l2 = pred.tspoly3reg10, l3 = pred.tspoly2reg100,
          l4 = pred.tspoly3reg100, l5 = pred.tspoly2reg1000, l6 = pred.tspoly3reg1000,
          labels = c ("Polynomial 2 10", "Polynomial 3 10", "Polynomial 2 100", "Polynomial 3 100",
                      "Polynomial 2 1000", "Polynomial 3 1000"), ymax = 200)
ploteval (measure = "mae", l1 = pred.tspoly2reg10, l2 = pred.tspoly3reg10, l3 = pred.tspoly2reg100,
          l4 = pred.tspoly3reg100, l5 = pred.tspoly2reg1000, l6 = pred.tspoly3reg1000,
          labels = c ("Polynomial 2 10", "Polynomial 3 10", "Polynomial 2 100", "Polynomial 3 100",
                      "Polynomial 2 1000", "Polynomial 3 1000"), ymax = 200)
ploteval (measure = "smape", l1 = pred.arima10, l2 = pred.arima100, l3 = pred.arima1000,
          labels = c ("ARIMA (10 states)", "ARIMA (100 states)", "ARIMA (1000 states)"))
ploteval (measure = "mae", l1 = pred.arima10, l2 = pred.arima100, l3 = pred.arima1000,
          labels = c ("ARIMA (10 states)", "ARIMA (100 states)", "ARIMA (1000 states)"))
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/autoreg.smape.pdf")
ploteval (measure = "smape", l1 = pred.naivetrend, l2 = pred.tslinreg1000, l3 = pred.tspoly2reg1000,
          l4 = pred.tspoly3reg1000, l5 = pred.arima1000,
          labels = c ("Naive trend", "Lin. reg.", "Poly. reg. 2", "Poly. reg. 3", "ARIMA"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/autoreg.mae.pdf")
ploteval (measure = "mae", l1 = pred.naivetrend, l2 = pred.tslinreg1000, l3 = pred.tspoly2reg1000,
          l4 = pred.tspoly3reg1000, l5 = pred.arima1000,
          labels = c ("Naive trend", "Lin. reg.", "Poly. reg. 2", "Poly. reg. 3", "ARIMA"))
dev.off ()

# RECHERCHE DU MEILLEUR K / SÉLECTION DES "VOISINS"
ks = 1:33
pred.knn.k = NULL
for (k in ks)
{
  pred = load.predictions (paste ("pred.knn.k", k, sep = ""))
  pred.knn.k = c (pred.knn.k, list (pred))
}
comp.knn.k.smape = compare.results ("smape", pred.knn.k)
comp.knn.k.smape
t (apply (comp.knn.k.smape, 1, order))
comp.knn.k.mae = compare.results ("mae", pred.knn.k)
comp.knn.k.mae
t (apply (comp.knn.k.mae, 1, order))
pred.kfn1 = load.predictions ("pred.kfn1")
pred.kfn16 = load.predictions ("pred.kfn16")
pred.krn1 = load.predictions ("pred.krn1")
pred.krn16 = load.predictions ("pred.krn16")
pred.maxnn = load.predictions ("pred.maxnn")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/neighbors.smape.pdf")
ploteval (measure = "smape", predictions = pred.knn.k, labels = paste ("k =", 1:33), legend = F)
ploteval (measure = "smape", l1 = pred.knn.k [[1]],
          l2 = pred.knn.k [[16]],
          l3 = pred.kfn1,
          l4 = pred.kfn16,
          l5 = pred.krn1,
          l6 = pred.krn16,
          l7 = pred.maxnn,
          labels = c ("1-NN", "16-NN", "1-FN", "16-FN", "1-RN", "16-RN", "All"), add = T, legend = F)
legend ("topright", lty = c (1:7, 1), col = c ("red", "blue", "forestgreen", "purple", "orange", "cyan3", "limegreen", "grey"), lwd = 2, cex = 1.5,
        legend = c ("1-NN", "16-NN", "1-FN", "16-FN", "1-RN", "16-RN", "All", "Other"), bg = "white")
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/neighbors.mae.pdf")
ploteval (measure = "mae", predictions = pred.knn.k, labels = paste ("k =", 1:33), legend = F)
ploteval (measure = "mae", l1 = pred.knn.k [[1]],
          l2 = pred.knn.k [[16]],
          l3 = pred.kfn1,
          l4 = pred.kfn16,
          l5 = pred.krn1,
          l6 = pred.krn16,
          l7 = pred.maxnn,
          labels = c ("1-NN", "16-NN", "1-FN", "16-FN", "1-RN", "16-RN", "All"), add = T, legend = F)
legend ("topright", lty = c (1:7, 1), col = c ("red", "blue", "forestgreen", "purple", "orange", "cyan3", "limegreen", "grey"), lwd = 2, cex = 1.5,
        legend = c ("1-NN", "16-NN", "1-FN", "16-FN", "1-RN", "16-RN", "All", "Other"), bg = "white")
dev.off ()

# MÉTHODE D'ADAPTATION DE K-NN
pred.knn.last.mean = load.predictions ("pred.knn.last.mean")
pred.knn.last.shift.mean = load.predictions ("pred.knn.last.shift.mean")
pred.knn.last.coeff.mean = load.predictions ("pred.knn.last.coeff.mean")
pred.knn.last.shift.coeff.mean = load.predictions ("pred.knn.last.shift.coeff.mean")
pred.knn.last.median = load.predictions ("pred.knn.last.median")
pred.knn.last.shift.median = load.predictions ("pred.knn.last.shift.median")
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pred.knn.last.shift.coeff.median = load.predictions ("pred.knn.last.shift.coeff.median")
comp.knn.adapt.smape = compare.results ("smape", l1 = pred.knn.last.mean, l2 = pred.knn.last.shift.mean,
                                        l3 = pred.knn.last.coeff.mean, l4 = pred.knn.last.shift.coeff.mean,
                                        l5 = pred.knn.last.median, l6 = pred.knn.last.shift.median,
                                        l7 = pred.knn.last.coeff.median, l8 = pred.knn.last.shift.coeff.median)
comp.knn.adapt.smape
t (apply (comp.knn.adapt.smape, 1, order))
comp.knn.adapt.mae = compare.results ("mae", l1 = pred.knn.last.mean, l2 = pred.knn.last.shift.mean,
                                      l3 = pred.knn.last.coeff.mean, l4 = pred.knn.last.shift.coeff.mean,
                                      l5 = pred.knn.last.median, l6 = pred.knn.last.shift.median,
                                      l7 = pred.knn.last.coeff.median, l8 = pred.knn.last.shift.coeff.median)
comp.knn.adapt.mae
t (apply (comp.knn.adapt.mae, 1, order))
ploteval (measure = "smape", l1 = pred.knn.last.mean, l2 = pred.knn.last.shift.mean, l3 = pred.knn.last.coeff.mean,
          l4 = pred.knn.last.shift.coeff.mean, labels = c ("k-NN (mean)", "k-NN (mean+shift)", "k-NN (mean+coeff)", "k-NN (mean+shift+coeff)"))
ploteval (measure = "mae", l1 = pred.knn.last.mean, l2 = pred.knn.last.shift.mean, l3 = pred.knn.last.coeff.mean,
          l4 = pred.knn.last.shift.coeff.mean, labels = c ("k-NN (mean)", "k-NN (mean+shift)", "k-NN (mean+coeff)", "k-NN (mean+shift+coeff)"))
ploteval (measure = "smape", l1 = pred.knn.last.median, l2 = pred.knn.last.shift.median, l3 = pred.knn.last.coeff.median,
          l4 = pred.knn.last.shift.coeff.median, labels = c ("k-NN (median)", "k-NN (median+shift)", "k-NN (median+coeff)", "k-NN (median+shift+coeff)"))
ploteval (measure = "mae", l1 = pred.knn.last.median, l2 = pred.knn.last.shift.median, l3 = pred.knn.last.coeff.median,
          l4 = pred.knn.last.shift.coeff.median, labels = c ("k-NN (median)", "k-NN (median+shift)", "k-NN (median+coeff)", "k-NN (median+shift+coeff)"))
ploteval (measure = "smape", l1 = pred.knn.last.shift.coeff.mean, l2 = pred.knn.last.coeff.median,
          labels = c ("k-NN (mean+shift+coeff)", "k-NN (median+coeff)"))
ploteval (measure = "mae", l1 = pred.knn.last.shift.coeff.mean, l2 = pred.knn.last.coeff.median,
          labels = c ("k-NN (mean+shift+coeff)", "k-NN (median+coeff)"))

pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/adaptation.smape.pdf")
ploteval (measure = "smape", l1 = pred.knn.last.mean,
          l2 = pred.knn.last.shift.mean,
          l3 = pred.knn.last.coeff.mean,
          l4 = pred.knn.last.median,
          l5 = pred.knn.last.shift.median,
          l6 = pred.knn.last.coeff.median,
          labels = c ("k-NN (mean)",
                      "k-NN (mean+shift)",
                      "k-NN (mean+coeff)",
                      "k-NN (median)",
                      "k-NN (median+shift)",
                      "k-NN (median+coeff)"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/adaptation.mae.pdf")
ploteval (measure = "mae", l1 = pred.knn.last.mean,
          l2 = pred.knn.last.shift.mean,
          l3 = pred.knn.last.coeff.mean,
          l4 = pred.knn.last.median,
          l5 = pred.knn.last.shift.median,
          l6 = pred.knn.last.coeff.median,
          labels = c ("k-NN (mean)",
                      "k-NN (mean+shift)",
                      "k-NN (mean+coeff)",
                      "k-NN (median)",
                      "k-NN (median+shift)",
                      "k-NN (median+coeff)"))
dev.off ()

# K-NN, MESURES DE DISTANCES, REPRÉSENTATION DES SÉRIES
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pred.knneuclid10 = load.predictions ("pred.knneuclid10")
pred.knneuclid100 = load.predictions ("pred.knneuclid100")
pred.knneuclid1000 = load.predictions ("pred.knneuclid1000")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/length.smape.pdf")
ploteval (measure = "smape", l0 = pred.knn.last.coeff.median,
          l1 = pred.knneuclid10, l2 = pred.knneuclid100, l3 = pred.knneuclid1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/length.mae.pdf")
ploteval (measure = "mae", l0 = pred.knn.last.coeff.median,
          l1 = pred.knneuclid10, l2 = pred.knneuclid100, l3 = pred.knneuclid1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
dev.off ()

pred.knnmahalanobis10 = load.predictions ("pred.knnmahalanobis10")
pred.knnmahalanobis100 = load.predictions ("pred.knnmahalanobis100")
pred.knnmahalanobis1000 = load.predictions ("pred.knnmahalanobis1000")
ploteval (measure = "smape", l0 = pred.knn.last.coeff.median,
          l1 = pred.knnmahalanobis10, l2 = pred.knnmahalanobis100, l3 = pred.knnmahalanobis1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
ploteval (measure = "mae", l0 = pred.knn.last.coeff.median,
          l1 = pred.knnmahalanobis10, l2 = pred.knnmahalanobis100, l3 = pred.knnmahalanobis1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
pred.knnseuclid10 = load.predictions ("pred.knnseuclid10")
pred.knnseuclid100 = load.predictions ("pred.knnseuclid100")
pred.knnseuclid1000 = load.predictions ("pred.knnseuclid1000")
ploteval (measure = "smape", l0 = pred.knn.last.coeff.median,
          l1 = pred.knnseuclid10, l2 = pred.knnseuclid100, l3 = pred.knnseuclid1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
ploteval (measure = "mae", l0 = pred.knn.last.coeff.median,
          l1 = pred.knnseuclid10, l2 = pred.knnseuclid100, l3 = pred.knnseuclid1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
pred.knndiff10 = load.predictions ("pred.knndiff10")
pred.knndiff100 = load.predictions ("pred.knndiff100")
pred.knndiff1000 = load.predictions ("pred.knndiff1000")
ploteval (measure = "smape", l0 = pred.knn.last.coeff.median,
          l1 = pred.knndiff10, l2 = pred.knndiff100, l3 = pred.knndiff1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
ploteval (measure = "mae", l0 = pred.knn.last.coeff.median,
          l1 = pred.knndiff10, l2 = pred.knndiff100, l3 = pred.knndiff1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
pred.knndtw10 = load.predictions ("pred.knndtw10")
pred.knndtw100 = load.predictions ("pred.knndtw100")
pred.knndtw1000 = load.predictions ("pred.knndtw1000")
ploteval (measure = "smape", l0 = pred.knn.last.coeff.median,
          l1 = pred.knndtw10, l2 = pred.knndtw100, l3 = pred.knndtw1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
ploteval (measure = "mae", l0 = pred.knn.last.coeff.median,
          l1 = pred.knndtw10, l2 = pred.knndtw100, l3 = pred.knndtw1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
pred.knnsdtw10 = load.predictions ("pred.knnsdtw10")
pred.knnsdtw100 = load.predictions ("pred.knnsdtw100")
pred.knnsdtw1000 = load.predictions ("pred.knnsdtw1000")
ploteval (measure = "smape", l0 = pred.knn.last.coeff.median,
          l1 = pred.knnsdtw10, l2 = pred.knnsdtw100, l3 = pred.knnsdtw1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
ploteval (measure = "mae", l0 = pred.knn.last.coeff.median,
          l1 = pred.knnsdtw10, l2 = pred.knnsdtw100, l3 = pred.knnsdtw1000,
          labels = c ("Current state ", "10 states", "100 states", "1000 states"))
ploteval (measure = "smape", l1 = pred.knneuclid100, l2 = pred.knnseuclid100, l3 = pred.knndiff100,
          l4 = pred.knndtw100, ymax = 120,
          labels = c ("Euc. dist (raw)", "Eucl. dist. (norm.)", "Differential", "DTW (raw)"))
ploteval (measure = "mae", l1 = pred.knneuclid100, l2 = pred.knnseuclid100, l3 = pred.knndiff100,
          l4 = pred.knndtw100, ymax = 150,
          labels = c ("Euc. dist (raw)", "Eucl. dist. (norm.)", "Differential", "DTW (raw)"))
pred.knneuclid100 = load.predictions ("pred.knneuclid100")
pred.knnseuclid100 = load.predictions ("pred.knnseuclid100")
pred.knnmahalanobis100 = load.predictions ("pred.knnmahalanobis100")
pred.knndtw100 = load.predictions ("pred.knndtw100")
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/dissimilarity.smape.pdf")
ploteval (measure = "smape",
          labels = c ("Euc. dist (raw)", "Euc. dist (norm.)", "Mahalanobis", "DTW", "Current state"),
          l1 = pred.knneuclid100,
          l2 = pred.knnseuclid100,
          l3 = pred.knnmahalanobis100,
          l4 = pred.knndtw100,
          l5 = pred.knn.last.coeff.median)
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/dissimilarity.mae.pdf")
ploteval (measure = "mae",
          labels = c ("Euc. dist (raw)", "Euc. dist (norm.)", "Mahalanobis", "DTW", "Current state"),
          l1 = pred.knneuclid100,
          l2 = pred.knnseuclid100,
          l3 = pred.knnmahalanobis100,
          l4 = pred.knndtw100,
          l5 = pred.knn.last.coeff.median)
dev.off ()
comp.dist.smape = compare.results ("smape", l1 = pred.knneuclid100, l2 = pred.knndtw100, l3 = pred.knn.last.coeff.median)
comp.dist.smape
t (apply (comp.dist.smape, 1, order))
comp.dist.mae = compare.results ("mae", l1 = pred.knneuclid100, l2 = pred.knndtw100, l3 = pred.knn.last.coeff.median)
comp.dist.mae
t (apply (comp.dist.mae, 1, order))

# K-NN AVEC DES SÉRIES INCOMPLÈTES IRRÉGULIÈRES
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pred.knn.resample1 = load.predictions ("pred.knn.resample1")
pred.knn.resample2 = load.predictions ("pred.knn.resample2")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/irregular.smape.pdf")
ploteval (measure = "smape", l1 = pred.knn.last.coeff.median, l3 = pred.knn.resample2,
          labels = c ("Regular series", "Irregular series"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/irregular.mae.pdf")
ploteval (measure = "mae", l1 = pred.knn.last.coeff.median, l3 = pred.knn.resample2,
          labels = c ("Regular series", "Irregular series"))
dev.off ()

# SÉLECTION DE VARIABLES
pred.knn.select = load.multitest ()
names = load.names ()
comp.knn.select.smape = compare.results ("smape", pred.knn.select)
comp.knn.select.mae = compare.results ("mae", pred.knn.select)
chosen1 = which (names == "MB")
chosen2 = which (names == "MC")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/selection.smape.pdf")
ploteval (measure = "smape", predictions = pred.knn.select, labels = "", legend = F, alpha = .05)
ploteval (measure = "smape", l1 = pred.knn.select [[1]], add = T, legend = F)
legend ("topright", lty = c (1, 1), col = c ("red", "grey"), lwd = 3, cex = 1.5,
        legend = c ("Current money", "Other"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/selection.mae.pdf")
ploteval (measure = "mae", predictions = pred.knn.select, labels = "", legend = F, alpha = .05)
ploteval (measure = "mae", l1 = pred.knn.select [[1]], add = T, legend = F)
legend ("topright", lty = c (1, 1), col = c ("red", "grey"), lwd = 3, cex = 1.5,
        legend = c ("Current money", "Other"))
dev.off ()

# COMPARATIF GÉNÉRAL
pred.naivetrend = load.predictions ("pred.naivetrend")
pred.tslinreg1000 = load.predictions ("pred.tslinreg1000")
pred.arima1000 = load.predictions ("pred.arima1000")
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/global.smape.pdf")
ploteval (measure = "smape", l1 = pred.naivetrend, l2 = pred.tslinreg1000, l3 = pred.arima1000, l4 = pred.knn.last.coeff.median,
          labels = c ("Naive trend", "Linear regression", "ARIMA", "k-NN"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/global.mae.pdf")
ploteval (measure = "mae", l1 = pred.naivetrend, l2 = pred.tslinreg1000, l3 = pred.arima1000, l4 = pred.knn.last.coeff.median,
          labels = c ("Naive trend", "Linear regression", "ARIMA", "k-NN"))
dev.off ()

# ÉVALUATION SELON LE SUCCÈS
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/success.failed.smape.pdf")
plotevalsf (pred.knn.last.coeff.median, measure = "smape")
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/success.failed.mae.pdf")
plotevalsf (pred.knn.last.coeff.median, measure = "mae")
dev.off ()

# PRÉDICTION DU NOMBRE DE BACKERS
pred.knn.backers = load.predictions ("pred.knn.backers")
ploteval (measure = "smape", l1 = pred.knn.backers, labels = c ("k-NN"))
ploteval (measure = "mae", l1 = pred.knn.backers, labels = c ("k-NN"))

# PRÉDICTION DU PLEDGE MOYEN
pred.knn.avpledge = load.predictions ("pred.knn.avpledge")
ploteval (measure = "smape", l1 = pred.knn.avpledge, labels = c ("k-NN"))
ploteval (measure = "mae", l1 = pred.knn.avpledge, labels = c ("k-NN"), ymax = 2)

# ÉVALUATION EN $
pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
pred.knn.backers = load.predictions ("pred.knn.backers")
pred.knn.avpledge = load.predictions ("pred.knn.avpledge")
pred.knn.dollars = load.predictions ("pred.knn.dollars")
pred.knn.ba = pred.knn.backers * pred.knn.avpledge
extract = read.table ("/home/blansche/Boulot/Recherche/Resultats/Kickstarter/extract.data", header = T)
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/knn.dollars.smape.pdf")
ploteval (measure = "smape", l1 = pred.knn.last.coeff.median, labels = "", legend = F)
ploteval (measure = "smape", l1 = pred.knn.dollars, labels = "", legend = F, add = T, n = 1)
ploteval (measure = "smape", l1 = pred.knn.ba, labels = "", legend = F, add = T, n = 2)
legend ("topright", lty = c (1, 2, 3), col = c ("red", "blue", "forestgreen"),
        lwd = 2, cex = 1.5,
        legend = c ("Pledged money in %", "Pledged money in $",
                    expression (paste ("Number of ", backers%*%Average, " pledge"))))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/knn.dollars.mae.pdf")
ploteval (measure = "mae", l1 = pred.knn.last.coeff.median, scale = extract [, 8],
          labels = "", legend = F, ymax = 10000)
ploteval (measure = "mae", l1 = pred.knn.dollars / 100, labels = "", legend = F, add = T, n = 1)
ploteval (measure = "mae", l1 = pred.knn.ba, scale = extract [, 8],
          labels = "", legend = F, add = T, n = 2)
legend ("topright", lty = c (1, 2, 3), col = c ("red", "blue", "forestgreen"),
        lwd = 2, cex = 1.5,
        legend = c ("Pledged money in %", "Pledged money in $",
                    expression (paste ("Number of ", backers%*%Average, " pledge"))))
dev.off ()

#######################################################################################################
# K-NN AVEC CLUSTERING
#######################################################################################################

pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
preds.knn.km = NULL
preds.knn.km.names = NULL
for (nbclusters in seq (5, 30, 5))
  for (kclust in 1:nbclusters)
  {
    pred = load.predictions (paste ("pred.knn.kmedians", nbclusters, ".k", kclust, sep = ""))
    if (!is.null (pred))
    {
      preds.knn.km = c (preds.knn.km, list (pred))
      preds.knn.km.names = c (preds.knn.km.names, paste (nbclusters, "/", kclust, sep = ""))
    }
  }
comp.knn.km.smape = compare.results ("smape", preds.knn.km)
colnames (comp.knn.km.smape) = preds.knn.km.names
comp.knn.km.smape
t (apply (comp.knn.km.smape, 1, function (v, n) n [order (v)], n = preds.knn.km.names))
comp.knn.km.mae = compare.results ("mae", preds.knn.km)
colnames (comp.knn.km.mae) = preds.knn.km.names
comp.knn.km.mae
t (apply (comp.knn.km.mae, 1, function (v, n) n [order (v)], n = preds.knn.km.names))
best = which (preds.knn.km.names == "30/5")
ploteval (measure = "smape", predictions = preds.knn.km, labels = "", legend = F)
ploteval (measure = "smape", l1 = preds.knn.km [[best]], labels = "", add = T, legend = F)
ploteval (measure = "smape", l1 = pred.knn.last.coeff.median, labels = "", add = T, n = 2, legend = F)
legend ("topright", lty = c (1, 1, 2), col = c ("red", "grey", "forestgreen"), lwd = 2, cex = 1.5,
        legend = c ("30/5", "Other values", "Without clustering"))
ploteval (measure = "mae", predictions = preds.knn.km, labels = "", legend = F)
ploteval (measure = "mae", l1 = preds.knn.km [[best]], labels = "", add = T, legend = F)
ploteval (measure = "mae", l1 = pred.knn.last.coeff.median, labels = "", add = T, n = 2, legend = F)
legend ("topright", lty = c (1, 1, 2), col = c ("red", "grey", "forestgreen"), lwd = 2, cex = 1.5,
        legend = c ("30/5", "Other values", "Without clustering"))

pred.knn.last.coeff.median = load.predictions ("pred.knn.last.coeff.median")
preds.knn.km = NULL
preds.knn.km.names = NULL
for (nbclusters in seq (5, 30, 5))
  for (kclust in 1:nbclusters)
  {
    pred = load.predictions (paste ("pred.knn.kmeans", nbclusters, ".k", kclust, sep = ""))
    if (!is.null (pred))
    {
      preds.knn.km = c (preds.knn.km, list (pred))
      preds.knn.km.names = c (preds.knn.km.names, paste (nbclusters, "/", kclust, sep = ""))
    }
  }
comp.knn.km.smape = compare.results ("smape", preds.knn.km)
colnames (comp.knn.km.smape) = preds.knn.km.names
comp.knn.km.smape
t (apply (comp.knn.km.smape, 1, function (v, n) n [order (v)], n = preds.knn.km.names))
comp.knn.km.mae = compare.results ("mae", preds.knn.km)
colnames (comp.knn.km.mae) = preds.knn.km.names
comp.knn.km.mae
t (apply (comp.knn.km.mae, 1, function (v, n) n [order (v)], n = preds.knn.km.names))
best = which (preds.knn.km.names == "30/5")
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/km.clust.smape.pdf")
ploteval (measure = "smape", predictions = preds.knn.km, labels = "", legend = F)
ploteval (measure = "smape", l1 = preds.knn.km [[best]], labels = "", add = T, legend = F)
ploteval (measure = "smape", l1 = pred.knn.last.coeff.median, labels = "", add = T, n = 2, legend = F)
legend ("topright", lty = c (1, 1, 2), col = c ("red", "grey", "forestgreen"), lwd = 2, cex = 1.5,
        legend = c ("30 clusters, 5 neighbors", "Other values", "Without clustering"))
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/km.clust.mae.pdf")
ploteval (measure = "mae", predictions = preds.knn.km, labels = "", legend = F)
ploteval (measure = "mae", l1 = preds.knn.km [[best]], labels = "", add = T, legend = F)
ploteval (measure = "mae", l1 = pred.knn.last.coeff.median, labels = "", add = T, n = 2, legend = F)
legend ("topright", lty = c (1, 1, 2), col = c ("red", "grey", "forestgreen"), lwd = 2, cex = 1.5,
        legend = c ("30 clusters, 5 neighbors", "Other values", "Without clustering"))
dev.off ()

time.knn = load.time ("knn")
time.knn [, 2] = time.knn [, 2] * 1000
time.knnkm = load.time ("knnkm")
time.knnkm [, 2] = time.knnkm [, 2] * 1000
size.knn = cbind.data.frame (Size = time.knn [, 1], Nbdist = time.knn [, 1])
size.knnkm = load.size ("knnkm")

pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/km.clust.time.pdf")
plot (time.knn, xlab = "Size of the learning set", ylab = "Running time (ms)", col = "red", xlim = c (0, 15000),
      cex.axis = 1.5, cex.lab = 1.5, cex = 2, lwd = 3, panel.first = grid (), ylim = c (0, max (time.knn [, 2])))
abline (lm (Time ~ Size, time.knn), col = "red", lwd = 3)
points (time.knnkm, col = "blue", cex = 2, lwd = 3, pch = 2)
abline (lm (Time ~ Size, time.knnkm), col = "blue", lwd = 3)
legend ("topleft", pch = 1:2, col = c ("red", "blue"), legend = c ("Without clustering", "With clustering"),
        lwd = 3, cex = 1.5, bg = "white")
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/km.clust.ratio.pdf")
plot (time.knn [, 1], time.knnkm [, 2] / time.knn [, 2], xlab = "Size of the learning set", ylab = "Ratio", col = "red", xlim = c (0, 15000),
      cex.axis = 1.5, cex.lab = 1.5, cex = 2, lwd = 3, panel.first = grid (), ylim = c (0, max (time.knnkm [, 2] / time.knn [, 2])))
points (time.knn [, 1], size.knnkm [, 2] / size.knn [, 2], col = "blue", cex = 2, lwd = 3, pch = 2)
legend ("topright", pch = 1:2, col = c ("red", "blue"), legend = c ("Running time", "Number of computed distances"),
        lwd = 3, cex = 1.5, bg = "white")
dev.off ()
pdf ("/home/blansche/Boulot/Recherche/Articles/En cours/blansche18case/images/km.clust.dist.pdf")
plot (size.knn, xlab = "Size of the learning set", ylab = "Number of computed distances", col = "red", xlim = c (0, 15000),
      cex.axis = 1.5, cex.lab = 1.5, cex = 2, lwd = 3, panel.first = grid (), ylim = c (0, max (time.knn [, 1])))
abline (lm (Nbdist ~ Size, size.knn), col = "red", lwd = 3)
points (size.knnkm, col = "blue", cex = 2, lwd = 2, pch = 2)
abline (lm (Nbdist ~ Size, size.knnkm), col = "blue", lwd = 3)
legend ("topleft", pch = 1:2, col = c ("red", "blue"), legend = c ("Without clustering", "With clustering"),
        lwd = 3, cex = 1.5, bg = "white")
dev.off ()
